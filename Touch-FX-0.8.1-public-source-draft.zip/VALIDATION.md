# Local Touch FX / AZ-MODS 1.2.6 adaptation

Target release source: be4be14e7c0a4af80d77b83575898161332ca4a1.
Original working 0.8.0 directories and player files have not been modified.

Changes:
- Reapply saved core and audio additions onto exact upstream release source.
- Remove launcher and trail-width registrations, leaving 16 rows. Always small A.CUE launcher; fixed Full trail, matching saved pre-update configuration. Pointer style and colour remain selectable.
- Restore normal 16-row registration limit; no per-mod 18-row exception.
- Keep upstream fitted button text and our aligned Touch FX choice geometry.
- Preserve upstream native STEMS FX files, per-stem read hooks, original-path bypass while FX is active, and Drum Roll HOLD core/bus logic.
- Keep our post-render STEMS FX and a single additive sampler generator. Physical/HOLD input and screen input feed an OR gate; the screen release only shortens its voice if physical/HOLD input is absent.
- Bind native geometry to the freshly built core hash and measured g_pl_view symbol offset. No removed hash validation.
- Existing GLIBC 2.17 powf binding retained for custom audio.

Executed tests (ARM64 build container):
- Panel: 16-row initialization; mixer follow in both directions; inactive SLIP/pad preparation; per-deck/per-panel memory; sampler auto-arm; bank buttons; native mute/EQ visual state; pointer styles/colours; glass and input lifecycle: PASS.
- Native geometry rejection/scale tests: PASS.
- Transparent mask right-edge test: PASS.
- Sampler audio/bank/loading/timing suite: 96 passed, 0 failed.
- Upstream STEMS FX DSP/press state suite against port source: 30 passed, 0 failed.
- Upstream HOLD pad, sustain, release, deck and concurrent input suite extracted from port core: PASS.

Limits: unit tests are not a live hardware/audio coexistence test. New HOLD and STEMS pad FX still need listening tests together with Touch FX. Device transparency, boot, timing under live playback and native hit regions remain unverified for this new build. No installation or restart performed.
