/* SPDX-License-Identifier: GPL-3.0-only */
/* Feasibility prototype ONLY. Not linked into the player build.
 * A deterministic, additive vocal echo over decoded stereo source samples.
 * Immutable control snapshot per page; no stateful delay line, writes, allocation,
 * or dependence on read order. Release stops new sends, not existing echoes.
 * This is not a replacement for the existing post-DSP Echo: parameter smoothing,
 * ducking, page-latched controls and native pitch behavior need integration work.
 */
#ifndef TOUCHFX_VOCAL_ECHO_SOURCE_H
#define TOUCHFX_VOCAL_ECHO_SOURCE_H
#include <stdint.h>
#include <math.h>
typedef struct {
    int64_t begin, end; /* source send interval [begin,end), end<0 while held */
    int delay;         /* source frames, derived from the source beat grid */
    float amount;      /* 0..1 */
    unsigned track;
} vocal_echo_source;
static inline void vocal_echo_source_wet(const float *vocals, int64_t frames,
        int64_t i, unsigned track, const vocal_echo_source *p, float out[2]) {
    out[0]=out[1]=0;
    if(!vocals||!p||frames<=0||i<0||p->delay<1||p->begin<0||track!=p->track||
       !isfinite(p->amount)||p->amount<=0||p->amount>1)return;
    float feedback=.20f+.52f*p->amount, gain=.60f*p->amount;
    for(int n=1;n<=24;n++) {
        int64_t delta=(int64_t)n*p->delay;
        if(i<delta)break;
        int64_t j=i-delta;
        if(j<p->begin)break;
        if(j<frames&&(p->end<0||j<p->end)) {
            float l=vocals[2*j],r=vocals[2*j+1];
            out[0]+=gain*(isfinite(l)?l:0);
            out[1]+=gain*(isfinite(r)?r:0);
        }
        gain*=feedback;
        if(gain<1e-7f)break;
    }
}
#endif
