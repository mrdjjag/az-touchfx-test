/* SPDX-License-Identifier: GPL-3.0-only */
/* Experimental additive vocal-only source echo. Independent of native pad FX.
 * Uses native bounded sequence snapshots and page latches. No source mutation,
 * no allocation and no stateful audio history in the source read hook.
 * Depth/rate changes apply to newly rendered pages; not the existing post-DSP
 * Echo's delay crossfade/ducking. A 24-tap cap bounds work and cuts below -60 dB.
 */
#include "vocal_echo_source.h"
static sfx_slot g_vocal_echo[NDECK];
static _Atomic unsigned g_vocal_beat[NDECK],g_vocal_screen[NDECK],g_vocal_age[NDECK];
static unsigned g_vocal_seen[NDECK]; /* deck render callback only */
int azstem_stem_fx_level(void);
int azstem_vocal_echo_test(int deck,int screen,int send,int rate,int amount);
int azstem_vocal_echo_test(int deck,int screen,int send,int rate,int amount){
 if(deck<0||deck>=NDECK)return 0;
 sfx_slot *s=&g_vocal_echo[deck];
 atomic_fetch_add_explicit(&g_vocal_beat[deck],1,memory_order_release);
 atomic_store_explicit(&g_vocal_screen[deck],screen!=0,memory_order_release);
 if(!screen){unsigned q;if(sfx_begin(s,&q)){atomic_store_explicit(&s->kind,0,memory_order_relaxed);sfx_end(s,q);}return 0;}
 deck_stems *dk=&g_dk[deck];
 unsigned tg=atomic_load_explicit(&g_deck_trackgen[deck],memory_order_relaxed);
 long long S=atomic_load_explicit(&g_play_obs[deck],memory_order_relaxed);
 long off=atomic_load_explicit(&dk->stem_off,memory_order_relaxed);
 if(!send){sfx_release(s,S>=off?S-off:0);return 1;}
 if(S<off||dk->stem_frames<=0||!dk->stem[0]||!(atomic_load_explicit(&dk->ctrl,memory_order_relaxed)&0x80u))return 0;
 double beat=sfx_beat(deck),beats=rate==9?4.0:rate==7?.75:rate==8?2.0/3.0:rate>=0&&rate<=5?(1<<rate)/16.0:0;
 if(beat<=0||beats<=0)return 0;
 long long delay=(long long)(beat*beats+.5);if(delay<1||delay>264600)return 0;
 if(amount<0)amount=0;if(amount>1000)amount=1000;
 int level=azstem_stem_fx_level();if(level<0)level=0;if(level>2000)level=2000;
 int control=1+amount+(level<<10);
 sfx_snap snap;
 if(!sfx_read(s,&snap,tg)||snap.offq>=0)return sfx_press(s,control,S-off,delay,tg);
 unsigned q;if(!sfx_begin(s,&q))return 0;
 atomic_store_explicit(&s->kind,control,memory_order_relaxed);
 atomic_store_explicit(&s->len,delay,memory_order_relaxed);
 sfx_end(s,q);return 1;
}
static void vocal_echo_test_tick(int d,int frames){
 if(d<0||d>=NDECK)return;
 unsigned beat=atomic_load_explicit(&g_vocal_beat[d],memory_order_acquire);
 if(beat!=g_vocal_seen[d]){g_vocal_seen[d]=beat;atomic_store_explicit(&g_vocal_age[d],0,memory_order_relaxed);}
 else {unsigned age=atomic_load_explicit(&g_vocal_age[d],memory_order_relaxed);if(age<44100)atomic_store_explicit(&g_vocal_age[d],age+(unsigned)frames,memory_order_relaxed);}
}
typedef struct {vocal_echo_source p;float volume;int valid;} vocal_echo_page;
static int vocal_echo_page_prepare(int d,long long b0,long long b1,vocal_echo_page *p){
 p->valid=0;
 if(!atomic_load_explicit(&g_vocal_screen[d],memory_order_acquire)||atomic_load_explicit(&g_vocal_age[d],memory_order_relaxed)>=44100)return 0;
 unsigned tg=atomic_load_explicit(&g_deck_trackgen[d],memory_order_relaxed);sfx_snap snap;
 if(!sfx_read(&g_vocal_echo[d],&snap,tg))return 0;
 sfx_latch(&g_vocal_echo[d],&snap,b0,b1);
 if(snap.start<0||snap.start>=b1||(snap.off>=0&&b0>=snap.off+24*snap.len))return 0;
 unsigned packed=(unsigned)(snap.kind-1);
 p->p=(vocal_echo_source){.begin=snap.start,.end=snap.off,.delay=(int)snap.len,.amount=(packed&1023u)/1000.f,.track=tg};
 p->volume=(packed>>10)/1000.f;p->valid=1;return 1;
}
static inline void vocal_echo_page_add(const vocal_echo_page *p,const float *vocals,long nf,long long i,float *L,float *R){
 if(!p->valid)return;
 float wet[2];vocal_echo_source_wet(vocals,nf,i,p->p.track,&p->p,wet);
 *L+=p->volume*wet[0];*R+=p->volume*wet[1];
}
