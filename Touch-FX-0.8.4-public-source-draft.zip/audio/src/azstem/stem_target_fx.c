/* SPDX-License-Identifier: GPL-3.0-only */
/* Experimental source-domain Echo/Gate for the first three stems. Snapshot
 * publication is bounded; pages/readers never modify source PCM. No DSP rings,
 * allocation, syscall or worker thread is added. Native pad FX remain separate. */
#include "vocal_echo_source.h"
#include "target_gate_source.h"
typedef struct {
 sfx_slot s;
 _Atomic long long anchor,previous_delay;
 _Atomic int previous_kind;
 _Atomic unsigned change_id;
 _Atomic uint64_t change_pk;
} target_slot;
static target_slot g_target_fx[NDECK];
static _Atomic unsigned g_target_beat[NDECK],g_target_screen[NDECK],g_target_age[NDECK];
static unsigned g_target_seen[NDECK];
int azstem_stem_fx_level(void);
static int target_pack(int amount,int level,unsigned mask,int mode){return 1+amount+(level<<10)+((int)(mask&7)<<21)+(mode==4?(1<<24):0);}
static int target_mode(int packed){return (((unsigned)(packed-1)>>24)&1)?4:2;}
static unsigned target_mask(int packed){return ((unsigned)(packed-1)>>21)&7;}
static float target_amount(int packed){return ((unsigned)(packed-1)&1023)/1000.f;}
static float target_volume(int packed){return (((unsigned)(packed-1)>>10)&2047)/1000.f;}
static void target_clear(target_slot *t){unsigned q;if(sfx_begin(&t->s,&q)){atomic_store_explicit(&t->s.kind,0,memory_order_relaxed);sfx_end(&t->s,q);}}
/* Read beat and anchor as one consistent native grid snapshot. */
static int target_grid(int d,double *beat,long long *anchor){
 drum_grid *g=&g_drum_grid[d];
 for(int n=0;n<8;n++){
  unsigned q=atomic_load_explicit(&g->seq,memory_order_acquire);if(q&1u)continue;
  double b=atomic_load_explicit(&g->beat_src,memory_order_relaxed);
  long long a=atomic_load_explicit(&g->anchor_src,memory_order_relaxed);
  int valid=atomic_load_explicit(&g->valid,memory_order_relaxed);
  atomic_thread_fence(memory_order_acquire);
  if(q!=atomic_load_explicit(&g->seq,memory_order_relaxed))continue;
  if(!valid||!isfinite(b)||b<1)return 0;
  *beat=b;*anchor=a;return 1;
 }return 0;
}
int mrdjjag_target_fx_abi(void);int mrdjjag_target_fx_abi(void){return 1;}
int azstem_target_fx_test(int d,int screen,int send,int rate,int mode,int amount,int targets);
int azstem_target_fx_test(int d,int screen,int send,int rate,int mode,int amount,int targets){
 if(d<0||d>=NDECK)return 0;
 target_slot *t=&g_target_fx[d];sfx_slot *s=&t->s;
 atomic_fetch_add_explicit(&g_target_beat[d],1,memory_order_release);
 deck_stems *dk=&g_dk[d];long off=atomic_load_explicit(&dk->stem_off,memory_order_relaxed);
 long long S=atomic_load_explicit(&g_play_obs[d],memory_order_relaxed),at=S>=off?S-off:0;
 unsigned was=atomic_load_explicit(&g_target_screen[d],memory_order_relaxed);
 unsigned mask=(unsigned)targets&7u;
 if(!screen||!mask||(mode!=2&&mode!=4)){
  sfx_release(s,at);atomic_store_explicit(&g_target_screen[d],2,memory_order_release);return 0;
 }
 if(was==2&&!send)target_clear(t); /* no old-tail restart when returning to a panel */
 atomic_store_explicit(&g_target_screen[d],1,memory_order_release);
 if(!send){sfx_release(s,at);return 1;}
 unsigned tg=atomic_load_explicit(&g_deck_trackgen[d],memory_order_relaxed);
 if(S<off||dk->stem_frames<=0||!(atomic_load_explicit(&dk->ctrl,memory_order_relaxed)&0x80u)){target_clear(t);return 0;}
 for(int k=0;k<3;k++)if(!dk->stem[k])mask&=~(1u<<k);
 if(!mask){target_clear(t);return 0;}
 double beat=0,beats=rate==9?4.0:rate==7?.75:rate==8?2.0/3.0:rate>=0&&rate<=5?(1<<rate)/16.0:0;long long anchor=0;
 if(beats<=0||!target_grid(d,&beat,&anchor)){target_clear(t);return 0;}
 long long delay=(long long)(beat*beats+.5);if(delay<1||delay>264600){target_clear(t);return 0;}
 if(amount<0)amount=0;if(amount>1000)amount=1000;
 int level=azstem_stem_fx_level();if(level<0)level=0;if(level>2000)level=2000;
 int packed=target_pack(amount,level,mask,mode);
 unsigned q;if(!sfx_begin(s,&q))return 0;
 int current=atomic_load_explicit(&s->kind,memory_order_relaxed);
 long long length=atomic_load_explicit(&s->len,memory_order_relaxed);
 int fresh=!current||atomic_load_explicit(&s->offq,memory_order_relaxed)>=0||atomic_load_explicit(&s->tg,memory_order_relaxed)!=tg||target_mode(current)!=mode||target_mask(current)!=mask;
 if(fresh){
  unsigned tag=atomic_load_explicit(&s->gen,memory_order_relaxed)+1;
  atomic_store_explicit(&s->gen,tag,memory_order_relaxed);atomic_store_explicit(&s->on,at,memory_order_relaxed);
  atomic_store_explicit(&s->offq,-1,memory_order_relaxed);atomic_store_explicit(&s->tg,tg,memory_order_relaxed);
  atomic_store_explicit(&s->start_pk,sfx_pack((long long)SFX_UNSET,tag),memory_order_relaxed);
  atomic_store_explicit(&s->off_pk,sfx_pack((long long)SFX_UNSET,tag),memory_order_relaxed);
 }
 if(fresh||current!=packed||length!=delay){
  atomic_store_explicit(&t->previous_kind,fresh?packed:current,memory_order_relaxed);
  atomic_store_explicit(&t->previous_delay,fresh?delay:length,memory_order_relaxed);
  unsigned change=atomic_load_explicit(&t->change_id,memory_order_relaxed)+1;
  atomic_store_explicit(&t->change_id,change,memory_order_relaxed);
  atomic_store_explicit(&t->change_pk,sfx_pack((long long)SFX_UNSET,change),memory_order_relaxed);
 }
 atomic_store_explicit(&s->kind,packed,memory_order_relaxed);atomic_store_explicit(&s->len,delay,memory_order_relaxed);
 atomic_store_explicit(&t->anchor,anchor-off,memory_order_relaxed);sfx_end(s,q);return 1;
}
/* Keep the tested vocal-only API available for older panels. */
int azstem_vocal_echo_test(int d,int screen,int send,int rate,int amount);
int azstem_vocal_echo_test(int d,int screen,int send,int rate,int amount){return azstem_target_fx_test(d,screen,send,rate,2,amount,1);}
static void vocal_echo_test_tick(int d,int frames){
 if(d<0||d>=NDECK)return;
 unsigned beat=atomic_load_explicit(&g_target_beat[d],memory_order_acquire);
 if(beat!=g_target_seen[d]){g_target_seen[d]=beat;atomic_store_explicit(&g_target_age[d],0,memory_order_relaxed);}
 else {unsigned age=atomic_load_explicit(&g_target_age[d],memory_order_relaxed);if(age<44100)atomic_store_explicit(&g_target_age[d],age+(unsigned)frames,memory_order_relaxed);}
}
typedef struct {vocal_echo_source p;float volume;int valid,mode,closing,previous_kind;unsigned mask;long long anchor,change,previous_delay;} vocal_echo_page;
static int vocal_echo_page_prepare(int d,long long b0,long long b1,vocal_echo_page *p){
 p->valid=0;p->mask=0;
 unsigned screen=atomic_load_explicit(&g_target_screen[d],memory_order_acquire);
 if(!screen||atomic_load_explicit(&g_target_age[d],memory_order_relaxed)>=44100)return 0;
 target_slot *t=&g_target_fx[d];sfx_snap snap;unsigned change=0;uint64_t pk=0;int ok=0;
 unsigned tg=atomic_load_explicit(&g_deck_trackgen[d],memory_order_relaxed);
 for(int n=0;n<8;n++){
  unsigned q=atomic_load_explicit(&t->s.seq,memory_order_acquire);if(q&1u)continue;
  if(!sfx_read(&t->s,&snap,tg))return 0;
  p->anchor=atomic_load_explicit(&t->anchor,memory_order_relaxed);
  p->previous_kind=atomic_load_explicit(&t->previous_kind,memory_order_relaxed);
  p->previous_delay=atomic_load_explicit(&t->previous_delay,memory_order_relaxed);
  change=atomic_load_explicit(&t->change_id,memory_order_relaxed);pk=atomic_load_explicit(&t->change_pk,memory_order_relaxed);
  atomic_thread_fence(memory_order_acquire);if(q==atomic_load_explicit(&t->s.seq,memory_order_relaxed)){ok=1;break;}
 }if(!ok)return 0;
 sfx_latch(&t->s,&snap,b0,b1);
 if(snap.start<0||snap.start>=b1)return 0;
 p->mode=target_mode(snap.kind);p->closing=screen==2;
 if(snap.off>=0&&b0>=snap.off+((p->closing||p->mode==4)?256:24*snap.len))return 0;
 p->change=sfx_unpack(pk,change);
 if(p->change<0){uint64_t expected=sfx_pack((long long)SFX_UNSET,change);
  if(atomic_compare_exchange_strong_explicit(&t->change_pk,&expected,sfx_pack(b0,change),memory_order_relaxed,memory_order_relaxed))p->change=b0;
  else p->change=sfx_unpack(expected,change);
 }
 p->p=(vocal_echo_source){.begin=snap.start,.end=snap.off,.delay=(int)snap.len,.amount=target_amount(snap.kind),.track=tg};
 p->volume=target_volume(snap.kind);p->mask=target_mask(snap.kind);p->valid=1;return 1;
}
static inline void vocal_echo_page_add(const vocal_echo_page *p,int stem,const float *source,long nf,long long i,float *L,float *R){
 if(!p->valid||stem<0||stem>2||!(p->mask&(1u<<stem)))return;
 if(p->mode==4){
  float depth=p->p.amount*(p->volume>1?1:p->volume);
  float gain=target_gate_gain(i,p->p.begin,p->p.end,p->anchor,p->p.delay,depth);
  if(p->change>=0&&i<p->change+128&&p->previous_delay>0){
   float volume=target_volume(p->previous_kind);if(volume>1)volume=1;
   float previous=target_gate_gain(i,p->p.begin,p->p.end,p->anchor,(int)p->previous_delay,target_amount(p->previous_kind)*volume);
   gain=previous+target_smooth((float)(i-p->change+1)/128.f)*(gain-previous);
  }
  *L*=gain;*R*=gain;
 }else{
  float wet[2];vocal_echo_source_wet(source,nf,i,p->p.track,&p->p,wet);
  float gain=p->volume;
  if(p->closing&&p->p.end>=0&&i>=p->p.end)gain*=1-target_smooth((float)(i-p->p.end+1)/256.f);
  *L+=gain*wet[0];*R+=gain*wet[1];
 }
}
