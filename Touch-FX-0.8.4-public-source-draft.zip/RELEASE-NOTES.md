# Touch FX 0.8.4

For AZ-MODS 1.2.7. Echo and Gate can now target Vocals, Instrument and Bass separately or together; Drums are excluded. Switching effects preserves the selection. Press the current effect again to clear selections and release FX; the next fresh touch affects the whole mix. Other effects still affect the whole mix.

Requires matching custom core/audio and tracks separated with Kyle's Mod Manager. Author tested on XDJ-AZ firmware 2.01. Source review/WIP, not a standalone or officially signed release.
