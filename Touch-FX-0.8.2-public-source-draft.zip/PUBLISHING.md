# Publication

Source review distribution only. Do not publish local binaries, backups, generated resource headers, settings or private archives. This is not yet a standalone index entry. Official signing/acceptance is not confirmed.
