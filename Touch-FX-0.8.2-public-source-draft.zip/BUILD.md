# Build 0.8.2

Use the ARM64 Ubuntu 18.04 GCC7 toolchain documented in core/UPSTREAM-BUILDING.md and SDK commit in PROVENANCE.json.
In core/, run `python3 tools/extract-assets.py /path/to/official-1.2.7/azmod.so` to reconstruct all 13 verified resource headers. These headers and their firmware-derived bytes are not published here.
From the source root, run `AZ_SDK_INCLUDE=/absolute/sdk/include sh build-all.sh` inside the build container.
The audio Makefile retains the GLIBC 2.17 powf binding.
The panel requires its matching custom core/audio. Its native geometry checks validate the exact core hash and g_pl_view offset in BOTH geometry_bridge.h files; if rebuilding changes the hash, inspect the full core symbol table and update both bindings. Never guess an offset or remove validation.
Local component builds and tests passed. This new public archive has not independently undergone a clean container rebuild; consult VERIFICATION.json for tested binary hashes. No claim of official signing or one-click installation.
