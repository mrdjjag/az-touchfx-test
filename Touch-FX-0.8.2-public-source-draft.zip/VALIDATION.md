# Touch FX 0.8.2 local adaptation for AZ-MODS 1.2.7

Exact upstream release source: 1c635c29df396305c187c1f63819bc1bbeff7f0d.
Prior working 1.2.6 source/binaries preserved. Full current MODS/settings backup verified on PC and USB before installation.

Source changes: reapply custom 1.2.6 additions onto exact 1.2.7; retain all upstream changes. Menu uses 1.2.7 responsive choice sizing/wrapping in place of the earlier custom choice layout. Preserve native-touch/bank toggles, 16 settings, fixed small launcher and saved Full trail. Preserve pointer choices and adaptive transparent layouts. Keep both the native and custom appended audio exports.

Important semantic merge: upstream 1.2.7 empty-deck master follow was also applied to our sampler render branch, including motion/stall detection, source publication and leader grid/subdivision selection. This prevents opening Touch FX from losing the upstream roll beat-lock improvement. Existing custom effect-grid fallback behavior remains unchanged.

Local ARM64 tests passed:
- Panel memory, mixer follow, inactive-deck preparation, mute/EQ visuals, bank options, pointer lifecycle and sixteen-row initialization.
- Native geometry validation and full-width transparency mask.
- Custom sampler audio/loading/bank/timing: 96 passed, zero failures.
- Upstream 1.2.7 native Drum Roll/grid/master-follow suite: 79 passed, zero failures.
- Same 79-check upstream suite with all render calls routed through our active sampler branch (FX bypass): passed. Includes moving master, paused master, stalled master, cleared follow and grid-rate conversion.
- Upstream 1.2.7 STEMS FX DSP/press-state: 40 passed, zero failures.
- Upstream HOLD pad/sustain/release/concurrency suite extracted from merged core: passed.

Binary checks: all original 1.2.7 and previous custom 1.2.6 core/audio exports must remain; GLIBC 2.17 only; exact core-hash/native-geometry binding retained for both panel readers. Hardware playback, menu rendering and combined effects need user confirmation after restart. No automatic restart or edits of cached libraries/security approvals.

Post-install check: Touch FX 0.8.2 loaded successfully on firmware 2.01. Running core/audio hashes and panel hash matched the verified build. The author reports normal operation. Broader long-duration and combined-effects testing remains limited.
