#!/bin/sh
set -eu
: "${AZ_SDK_INCLUDE:?Set AZ_SDK_INCLUDE to the SDK include directory}"
make -C core/src CC=gcc azmod
make -C audio/src CC=gcc azstem
make -C panel AZ_SDK_INCLUDE="$AZ_SDK_INCLUDE"
sha256sum core/src/out/azmod.so audio/src/out/azstem.so panel/out/mrdjjag-touchfx-test.so
