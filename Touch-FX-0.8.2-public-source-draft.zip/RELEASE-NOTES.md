# Touch FX 0.8.2

Adapted to AZ-MODS 1.2.7. Matching custom core/audio required. Sixteen registered settings; fixed small launcher and Full trail. Pointer style, colour, panel layouts and bank visibility options retained. Upstream STEMS pad FX and Drum Roll HOLD code retained. Author reports working on firmware 2.01; see validation limits.
